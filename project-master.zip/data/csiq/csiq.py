import os
import torch
import numpy as np
import cv2
import torch.nn.functional as F
from utils.process import RandCropp


class CSIQ(torch.utils.data.Dataset):
    def __init__(self, dis_path, txt_file_name, list_name, transform, keep_ratio):
        super(CSIQ, self).__init__()
        self.dis_path = "E:\\datasets\\_CSIQ\\CSIQ_distilling\\dst_imgs\\img\\"
        self.txt_file_name = "D:\\python_project\\MANIQA-master\\data\\csiq\\csiq.txt"
        self.transform = transform
        self.trans = RandCropp(440)

        dis_files_data, score_data = [], []
        with open("D:\\python_project\\MANIQA-master\\data\\csiq\\csiq.txt", 'r') as listFile:
            for line in listFile:
                dis, _, score = line.split()
                if _ in list_name:
                    dis_files_data.append(dis)
                    score_data.append(float(score))

        # reshape score_list (1xn -> nx1)
        score_data = np.array(score_data)
        score_data = self.normalization(score_data)
        score_data = list(score_data.astype('float').reshape(-1, 1))

        self.data_dict = {'d_img_list': dis_files_data, 'score_list': score_data}

    def normalization(self, data):
        range = np.max(data) - np.min(data)
        return (data - np.min(data)) / range

    def __len__(self):
        return len(self.data_dict['d_img_list'])

    def __getitem__(self, idx):
        d_img_name = self.data_dict['d_img_list'][idx]
        score = self.data_dict['score_list'][idx]
        d_img = cv2.imread(os.path.join(self.dis_path, d_img_name), cv2.IMREAD_COLOR)
        sample = {
            'd_img_org': d_img,
            'score': score
        }
        d_img = self.trans(sample)['d_img_org']
        d_img = cv2.resize(d_img, (224, 224), interpolation=cv2.INTER_CUBIC)
        d_img = cv2.cvtColor(d_img, cv2.COLOR_BGR2RGB)
        d_img = np.array(d_img).astype('float32') / 255
        d_img = np.transpose(d_img, (2, 0, 1))
        sample['d_img_org'] = d_img
        if self.transform:
            sample = self.transform(sample)
        return sample