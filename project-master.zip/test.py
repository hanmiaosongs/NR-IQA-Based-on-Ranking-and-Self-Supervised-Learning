# N = int(input())
# nums = [int(x) for x in input().split(' ')]
# ls = input()
#
# print(nums)
# print(ls)

# x, y = int(ls[0]), int(ls[-1])
# x, y = (x, y) if x < y else (y, x)
# # print(ls)
# # print(x, y)
#
# shun = sum(nums[x-1:y-1])
# # print(nums[x-1:y-1])
# # print(shun)
#
# ni = sum(nums[:x-1] + nums[y-1:])
# # print(nums[:x-1] + nums[y-1:])
# # print(ni)
#
# if shun < ni:
#     print(shun)
# else:
#     print(ni)







row, col = map(int, input().split(' '))
arr = []
for i in range(row):
    tmp = list(map(int, input().split(' ')))
    arr.append(tmp)

def sum_arr(ls):
    r, c = len(ls), len(ls[0])
    res = 0
    for i in range(r):
        for j in range(c):
            res += ls[i][j]
    return res

# 横切
ans = 1e8
# print(arr)
for i in range(1, row):
    s1 = sum_arr(arr[:i])
    s2 = sum_arr(arr[i:])
    if abs(s1-s2) < ans:
        ans = abs(s1-s2)
# print(ans)

# 转置
arrT = []
for i in range(col):
    tmp = []
    for j in range(row):
        tmp.append(arr[j][i])
    arrT.append(tmp)

for j in range(1, col):
    s1 = sum_arr(arrT[:j])
    s2 = sum_arr(arrT[j:])
    if abs(s1-s2) < ans:
        ans = abs(s1-s2)

print(ans)















