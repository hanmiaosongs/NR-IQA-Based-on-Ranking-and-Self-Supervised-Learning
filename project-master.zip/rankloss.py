import torch
import torchvision


class HingeLoss(torch.nn.Module):
    def __init__(self, batchsz):
        super(HingeLoss, self).__init__()

        self.batchsz = batchsz
        pass

    def forward(self, y_pre, y, device):
        turn = torch.ones([self.batchsz, 1]).to(device)
        zro = torch.zeros([self.batchsz, self.batchsz]).to(device)
        big = turn * y_pre
        margin_1 = turn*y

        turn_2 = torch.ones([1, self.batchsz]).to(device)
        y_preT = torch.reshape(y_pre, (self.batchsz, 1))
        yT = torch.reshape(y, (self.batchsz, 1))
        little = y_preT * turn_2
        margin_2 = yT * turn_2

        margin = margin_1 - margin_2
        confidence = big - little

        loss = margin - confidence
        loss = torch.where(loss > 0, loss, zro)
        loss = torch.where(margin > 0, loss, zro)
        ans = loss.sum()/(self.batchsz*(self.batchsz - 1))

        return ans
